<?php
session_start();
ini_set('display_errors', 1); 

// Include database connection
require_once '../config/connection.php'; // Load database connection settings
$databaseConnection = new PDO(Source_Name, DataBase_USER, DataBase_PASSWORD);

function recordPageAccess($dbConnection, $pageURL, $accessStatus) {
    // Retrieve the user's IP address
    $userIP = $_SERVER['REMOTE_ADDR'];
    
    // Determine if the user is logged in and capture their username, or set it to NULL
    $user = isset($_SESSION['username']) ? $_SESSION['username'] : null;
    
    // Prepare the SQL statement for inserting access log into the database
    $insertLogSQL = 'INSERT INTO access_logs (ip_address, url, username, access_allowed) VALUES (:ip_address, :url, :username, :access_allowed)';
    
    $preparedStatement = $dbConnection->prepare($insertLogSQL); // Prepare the SQL statement
    $preparedStatement->execute([ // Execute the prepared statement with the log details
        'ip_address' => $userIP,
        'url' => $pageURL,
        'username' => $user,
        'access_allowed' => $accessStatus
    ]);
}

// Usage Example: Log the access on your pages
$currentPage = $_SERVER['REQUEST_URI']; // Capture the requested URL
$accessGranted = true; // Determine access status (true or false)

// Log the access by calling the function
recordPageAccess($databaseConnection, $currentPage, $accessGranted);

// Start session and check if user has the required role
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'moderator')) {
    // Redirect to an error page if the user is unauthorized
    header('HTTP/1.0 403 Forbidden'); // Set response header for forbidden access
    echo "You do not have permission to access this page."; // Display permission error message
    exit; // Stop script execution
}

// Function to fetch access logs from the database
function fetchAccessLogs($dbConnection, $clientIP = null) {
    $fetchLogsSQL = 'SELECT * FROM access_logs'; // Prepare the SQL query to fetch logs
    
    if ($clientIP) { // Check if a specific IP address is provided
        $preparedStatement = $dbConnection->prepare($fetchLogsSQL); // Prepare the filtered SQL statement
        $preparedStatement->execute(['ip_address' => $clientIP]); // Execute the statement with the provided IP
    } else {
        $preparedStatement = $dbConnection->query($fetchLogsSQL); // Execute the general SQL query
    }
    
    return $preparedStatement->fetchAll(PDO::FETCH_ASSOC); // Fetch and return all logs as an associative array
}

// Function to present logs in an HTML table format
function renderLogsAsTable($logEntries) {
    echo "<table border='1'>"; // Start the HTML table
    echo "<tr><th>ID</th><th>Username</th><th>IP Address</th><th>Timestamp</th><th>URL</th><th>Access Allowed</th></tr>"; // Table headers
    foreach ($logEntries as $entry) { // Loop through each log entry
        echo "<tr>"; // Start a new row
        echo "<td>" . htmlspecialchars($entry['id']) . "</td>"; // Display log ID
        echo "<td>" . htmlspecialchars($entry['username']) . "</td>"; // Display username
        echo "<td>" . htmlspecialchars($entry['ip_address']) . "</td>"; // Display IP address
        echo "<td>" . htmlspecialchars($entry['timestamp']) . "</td>"; // Display timestamp
        echo "<td>" . htmlspecialchars($entry['url']) . "</td>"; // Display accessed URL
        echo "<td>" . ($entry['access_allowed'] ? 'Allowed' : 'Denied') . "</td>"; // Display access status
        echo "</tr>"; // End the row
    }
    echo "</table>"; // End the HTML table
}

// Function to present logs in a list format
function renderLogsAsList($logEntries) {
    echo "<ul>"; // Start an unordered list
    foreach ($logEntries as $entry) { // Loop through each log entry
        echo "<li>"; // Start a list item
        echo "ID: " . htmlspecialchars($entry['id']) . " - "; // Display log ID
        echo "Username: " . htmlspecialchars($entry['username']) . " - "; // Display username
        echo "IP: " . htmlspecialchars($entry['ip_address']) . " - "; // Display IP address
        echo "Timestamp: " . htmlspecialchars($entry['timestamp']) . " - "; // Display timestamp
        echo "URL: " . htmlspecialchars($entry['url']) . " - "; // Display accessed URL
        echo "Access: " . ($entry['access_allowed'] ? 'Allowed' : 'Denied'); // Display access status
        echo "</li>"; // End the list item
    }
    echo "</ul>"; // End the unordered list
}

// Function to render logs in JSON format
function renderLogsAsJSON($logEntries) {
    header('Content-Type: application/json; charset=utf-8'); // Set content type for JSON response
    echo json_encode($logEntries); // Output logs as JSON
}

// Function to render logs in XML format
function renderLogsAsXML($logEntries) {
    header('Content-Type: text/xml; charset=utf-8'); // Set content type for XML response
    $xmlDocument = new SimpleXMLElement('<logs/>'); // Create a new SimpleXMLElement
    
    foreach ($logEntries as $entry) { // Loop through each log entry
        $logNode = $xmlDocument->addChild('log'); // Add a new log node to XML
        $logNode->addChild('id', htmlspecialchars($entry['id'])); // Add ID element to log node
        $logNode->addChild('username', htmlspecialchars($entry['username'])); // Add username element to log node
        $logNode->addChild('ip_address', htmlspecialchars($entry['ip_address'])); // Add IP address element to log node
        $logNode->addChild('timestamp', htmlspecialchars($entry['timestamp'])); // Add timestamp element to log node
        $logNode->addChild('url', htmlspecialchars($entry['url'])); // Add URL element to log node
        $logNode->addChild('access_allowed', $entry['access_allowed'] ? 'Allowed' : 'Denied'); // Add access status element to log node
    }
    
    echo $xmlDocument->asXML(); // Output the XML document
}

// Handle user input for log retrieval
$clientIP = $_GET['ip_address'] ?? null; // Get IP address from query parameters
$logEntries = fetchAccessLogs($databaseConnection, $clientIP); // Fetch logs based on optional IP filter
$requestedFormat = $_GET['format'] ?? 'table'; // Get desired output format from query parameters, default to 'table'

// Output logs in requested format
if ($requestedFormat === 'json') {
    renderLogsAsJSON($logEntries); // Render logs as JSON
    exit; // Stop further processing since JSON is being output
}

if ($requestedFormat === 'xml') {
    renderLogsAsXML($logEntries); // Render logs as XML
    exit; // Stop further processing since XML is being output
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Log Page</title>
    <style>
        body {
            background: #c1bdba; /* Same background as the permissions page */
            font-family: 'Titillium Web', sans-serif;
            padding: 40px;
            margin: 0;
            background-image: url('https://images.pexels.com/photos/19417092/pexels-photo-19417092/free-photo-of-formula-1-red-bull-rb19-race-car-and-toyota-gr010-hybrid-le-mans-hypercar-in-front-of-the-heydar-aliyev-center-in-baku-azerbaijan.jpeg'); /* Replace with your image URL */
            background-size: cover; 
            background-position: center; 
            background-repeat: no-repeat; 
            background-attachment: fixed;
        }

        h1 {
            text-align: center;
            color: #ffffff;
            font-weight: 300;
            margin: 0 0 40px;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 20px;
        }

        label {
            color: #ffffff; /* Label color */
            margin: 10px 0 5px;
        }

        input[type="text"], select {
            padding: 10px;
            font-size: 1em;
            background: rgba(160, 179, 176, .25);
            color: #ffffff;
            border: 1px solid #a0b3b0;
            outline: none;
            width: 300px; /* Fixed width for inputs */
        }

        button {
            background-color: #1ab188;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            font-size: 1rem;
            text-transform: uppercase;
            transition: background .5s ease;
            margin-top: 10px;
        }

        button:hover {
            background-color: #178f70;
        }

        hr {
            border: 1px solid #ffffff; /* Horizontal rule style */
            margin: 20px 0;
        }

        .log-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0 auto;
            background: rgba(19, 35, 47, .9); /* Dark table background */
            box-shadow: 0 4px 10px 4px rgba(19, 35, 47, .3);
            border-radius: 4px;
            overflow: hidden;
        }

        th, td {
            padding: 15px;
            text-align: left;
            color: #ffffff; /* White text */
        }

        th {
            background-color: #1ab188; /* Green header background */
            text-transform: uppercase;
            font-size: 18px;
        }

        tr:nth-child(even) {
            background: rgba(160, 179, 176, .25); /* Light row color */
        }

        tr:hover {
            background: #178f70; /* Hover effect */
        }

        @media (max-width: 768px) {
            form {
                width: 100%;
            }

            input[type="text"], select {
                width: 100%; /* Full width for smaller screens */
            }
        }
    </style>
</head>
<body>

<h1>Access Logs</h1>

<!-- Filter and format selection form -->
<form method="get" action="auditLog.php">
    <label for="ip_address">Filter by IP (optional):</label>
    <input type="text" id="ip_address" name="ip_address" value="<?php echo htmlspecialchars($clientIP); ?>">
    
    <label for="format">Select Format:</label>
    <select id="format" name="format">
        <option value="table" <?php if ($requestedFormat == 'table') echo 'selected'; ?>>Table</option>
        <option value="list" <?php if ($requestedFormat == 'list') echo 'selected'; ?>>List</option>
        <option value="json" <?php if ($requestedFormat == 'json') echo 'selected'; ?>>JSON</option>
        <option value="xml" <?php if ($requestedFormat == 'xml') echo 'selected'; ?>>XML</option>
    </select>
    
    <button type="submit">View Logs</button>
</form>

<hr>

<?php
// Display the logs in the selected format for HTML views
if ($requestedFormat === 'list') {
    renderLogsAsList($logEntries);
} else {
    renderLogsAsTable($logEntries);
}
?>

</body>
</html>
