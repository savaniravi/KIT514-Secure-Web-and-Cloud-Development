<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        /* Hardcode the variables instead of SCSS syntax */
        body {
        background-image: url('https://images.pexels.com/photos/19417092/pexels-photo-19417092/free-photo-of-formula-1-red-bull-rb19-race-car-and-toyota-gr010-hybrid-le-mans-hypercar-in-front-of-the-heydar-aliyev-center-in-baku-azerbaijan.jpeg'); /* Replace with your image URL */
        background-size: cover; 
        background-position: center; 
        background-repeat: no-repeat; 
        background-attachment: fixed;
        }

        a {
            text-decoration: none;
            color: #1ab188;
            transition: .5s ease;
        }
        a:hover {
            color: #178f70;
        }

        .form {
            background: rgba(19, 35, 47, .9);
            padding: 40px;
            max-width: 600px;
            margin: 40px auto;
            border-radius: 4px;
            box-shadow: 0 4px 10px 4px rgba(19, 35, 47, .3);
        }

        .tab-group {
            list-style: none;
            padding: 0;
            margin: 0 0 40px 0;
            display: flex; /* Use flexbox to align items horizontally */
            justify-content: space-between;
        }
        .tab-group li {
            flex: 1; /* Ensures both tabs take up equal width */
        }
        .tab-group:after {
            content: "";
            display: table;
            clear: both;
        }
        .tab-group li a {
            display: block;
            padding: 15px;
            background: rgba(160, 179, 176, .25);
            color: #a0b3b0;
            font-size: 20px;
            float: left;
            width: 90%;
            text-align: center;
            cursor: pointer;
            transition: .5s ease;
        }
        .tab-group li a:hover {
            background: #178f70;
            color: #ffffff;
        }
        .tab-group .active a {
            background: #1ab188;
            color: #ffffff;
        }

        h1 {
            text-align: center;
            color: #ffffff;
            font-weight: 300;
            margin: 0 0 40px;
        }

        label {
            position: absolute;
            transform: translateY(6px);
            left: 13px;
            color: rgba(255, 255, 255, .5);
            transition: all 0.25s ease;
            font-size: 22px;
        }

        input, textarea {
            font-size: 22px;
            display: block;
            width: 100%;
            padding: 5px 10px;
            background: none;
            border: 1px solid #a0b3b0;
            color: #ffffff;
            transition: border-color .25s ease, box-shadow .25s ease;
        }
        input:focus {
            outline: 0;
            border-color: #1ab188;
        }

        .field-wrap {
            position: relative;
            margin-bottom: 40px;
        }

        .button {
            padding: 15px 0;
            font-size: 2rem;
            font-weight: 600;
            text-transform: uppercase;
            background: #1ab188;
            color: #ffffff;
            transition: all .5s ease;
            width: 100%;
            border: none;
            outline: none;
        }
        .button:hover, .button:focus {
            background: #178f70;
        }

        .forgot {
            margin-top: -20px;
            text-align: right;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {
            // Initially hide the login form
            $('#login').hide();

            $('.form').find('input, textarea').on('keyup blur focus', function (e) {
                var $this = $(this),
                    label = $this.prev('label');

                if (e.type === 'keyup') {
                    if ($this.val() === '') {
                        label.removeClass('active highlight');
                    } else {
                        label.addClass('active highlight');
                    }
                } else if (e.type === 'blur') {
                    if ($this.val() === '') {
                        label.removeClass('active highlight');
                    } else {
                        label.removeClass('highlight');
                    }
                } else if (e.type === 'focus') {
                    if ($this.val() === '') {
                        label.removeClass('highlight');
                    } else if ($this.val() !== '') {
                        label.addClass('highlight');
                    }
                }
            });

            $('.tab a').on('click', function (e) {
                e.preventDefault();

                $(this).parent().addClass('active');
                $(this).parent().siblings().removeClass('active');

                var target = $(this).attr('href');
                $('.tab-content > div').hide();  // Hide all forms
                $(target).fadeIn(600);  // Show the clicked form
            });
        });
        function validateForm() {
            var ipAddress = document.getElementById('ipAddress').value;
            var ipPattern = /^(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])(\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3}$/;
            var errorMessage = document.getElementById('error-message');

            // Validate IP address format
            if (!ipPattern.test(ipAddress)) {
                errorMessage.textContent = "Please enter a valid IP address (e.g. 192.168.1.1).";
                return false;
            }

            return true; // If validation passes
        }
    </script>
</head>
<body>
    <div class="form">
        <ul class="tab-group">
            <li class="tab active"><a href="#signup">Sign Up</a></li>
            <li class="tab"><a href="#login">Log In</a></li>
        </ul>

        <div class="tab-content">
            <div id="signup">
                <h1>Sign Up for Free</h1>
                <form method="POST" action="?behavior=register" onsubmit="return validateForm()">
                <div class="top-row">
                        <div class="field-wrap">
                            <input type="text" id="username" placeholder='username' name="username" required>
                        </div>
                        <div class="field-wrap">
                             
                            <input type="password" id="password" name="password" placeholder="password" required autocomplete="off" required/>
                        </div>
                    </div>
                    <div class="field-wrap">
                        <input type="text" id="drivers" name="drivers" placeholder="F1 driver's name" required>
                    </div>
                    <div class="field-wrap">
                        <input type="text" id="ipAddress" name="extra_data" placeholder="IP Address" required>
                    </div>
                    <div id="error-message" class="field-wrap error-message"></div>

                    <button type="submit" class="button button-block">Get Started</button>
                </form>
            </div>

            <div id="login">
                <h1>Welcome Back!</h1>
                <form method="POST" action="?behavior=login">
                    <div class="field-wrap">
                        <input type="text" id="username" placeholder="username" name="username" required>
                    </div>
                    <div class="field-wrap">
                        <input type="password" id="password" placeholder="password" name="password" required>
                    </div>
                    <button type="submit" class="button button-block">Log In</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
