<?php
// Start the session to store user information
session_start();

// Enable error display for debugging
ini_set('display_errors', 1);

// Include necessary files: the user model, autoload for dependencies, and database connection
require_once '../models/authModel.php';
require '../vendor/autoload.php';
require_once '../config/connection.php'; // Database connection configuration

// Create a new PDO connection using database credentials
$databaseConnection = new PDO(Source_Name, DataBase_USER, DataBase_PASSWORD);

// Instantiate the user model with the database connection
$authModel = new authModel($databaseConnection);

// Fetch the logged-in user's data by their username from the session
$accountDetails = $authModel->getAccountByAlias($_SESSION['username']);

// Define an encryption key for decrypting the stored custom data
$secretKey = 'abcdef';

// Decode the stored initialization vector (IV) from the database
$decryptionIV = base64_decode($accountDetails['salt']);

// Decrypt the stored 'drivers' information using AES-256-CBC
$favoriteDrivers = openssl_decrypt($accountDetails['drivers'], 'aes-256-cbc', $secretKey, 0, $decryptionIV);

// If decryption fails, display an error message
if ($favoriteDrivers === false) {
    echo "Decryption failed: " . openssl_error_string();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <style>
        /* Hardcoded variables for colors and styling */
        body {
            background: #c1bdba;
            font-family: 'Titillium Web', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://images.pexels.com/photos/19417092/pexels-photo-19417092/free-photo-of-formula-1-red-bull-rb19-race-car-and-toyota-gr010-hybrid-le-mans-hypercar-in-front-of-the-heydar-aliyev-center-in-baku-azerbaijan.jpeg'); /* Replace with your image URL */
            background-size: cover; 
            background-position: center; 
            background-repeat: no-repeat; 
            background-attachment: fixed;
        }

        /* Container for the dashboard */
        .dashboard-container {
            background: rgba(19, 35, 47, 0.75); /* Slightly lighter transparency */
            padding: 40px;
            max-width: 600px;
            margin: 40px auto;
            border-radius: 8px; /* Slightly more rounded corners */
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5); /* Softer shadow */
            color: #e0e0e0; /* Light gray text color */
        }

        h1, h2 {
            font-weight: 300;
            margin-bottom: 20px;
            color: #00ffcc; /* Light teal matching your background */
        }


        p {
            font-size: 1.1em;
            color: #b0c4de; /* Softer light blue-gray for better readability */
        }

        /* Button styling */
        .button-style {
            background: #00ffcc; /* Match button color with the background */
            color: #000; /* Dark text for contrast */
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            margin: 10px;
            cursor: pointer;
            font-size: 1.1em;
            display: inline-block;
            transition: background 0.3s ease;
            text-decoration: none;
        }

        .button-style:hover {
            background: #009999;
        }

        /* Location details styling */
        .location-details p {
            font-size: 1.1em;
            color: #d0d0d0;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php
        // Display a welcome message with the user's username
        echo "<h1>Welcome, " . htmlspecialchars($accountDetails['username']) . "</h1>";

        // Show the user's favorite drivers
        echo "<h2>Your Favorite Drivers: </h2>";
        echo "<p>" . htmlspecialchars($favoriteDrivers) . "</p>";

        // Choose API actions based on stored user options
        $userChoice = 1;
        switch ($userChoice) {
            case '1':
                // Fetch IP address stored in the user's extra data field
                $storedIPAddress = htmlspecialchars($accountDetails['extra_data']);

                // Use Guzzle to make an API call to get the location from the IP address
                $apiClient = new \GuzzleHttp\Client();
                $apiResponse = $apiClient->request('GET', 'https://ip-to-location1.p.rapidapi.com/myip', [
                    'headers' => [
                        'x-rapidapi-host' => 'ip-to-location1.p.rapidapi.com',
                        'x-rapidapi-key' => '7434d13e83mshd91af349e96c3abp191d5bjsn1d55a8d8e619'
                    ],
                    'query' => ['ip' => $storedIPAddress]
                ]);

                // Decode the response to extract the location data
                $locationDetails = json_decode($apiResponse->getBody(), true);

                // Display user's location information
                echo "<h2>Your IP Location:</h2>";

                // Extract and sanitize geographical data
                $geographicalDetails = $locationDetails['geo'];
                $userCountry = htmlspecialchars($geographicalDetails['country']);
                $userCity = !empty($geographicalDetails['city']) ? htmlspecialchars($geographicalDetails['city']) : 'Unknown City';
                $userLatitude = htmlspecialchars($geographicalDetails['ll'][0]);
                $userLongitude = htmlspecialchars($geographicalDetails['ll'][1]);

                // Display the extracted location information
                echo "<div class='location-details'>";
                echo "<p>Country: $userCountry</p>";
                echo "<p>City: $userCity</p>";
                echo "<p>Latitude: $userLatitude</p>";
                echo "<p>Longitude: $userLongitude</p>";
                echo "</div>";
                break;
        }
        ?>

        <!-- Buttons for navigating to different pages -->
        <a href="userRoles.php" class="button-style">Permissions Page</a>
        <a href="auditLog.php" class="button-style">Access Log Page</a>
        <a href="https://discord.com/oauth2/authorize?client_id=1289095716152803359&response_type=code&redirect_uri=http%3A%2F%2Flab-2105cf46-fd70-4e4b-8ece-4494323c5240.australiaeast.cloudapp.azure.com%3A7037%2FAssignment%2Fviews%2FDiscordGateway.php&scope=identify+guilds" class="button-style">Discord Page</a>
        <a href="sessionOut.php" class="button-style">Logout</a>

    </div>
</body>
</html>
