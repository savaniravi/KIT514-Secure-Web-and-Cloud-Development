<?php
ini_set('display_errors', 1); // Enable error reporting for debugging
session_start(); // Start the session to manage user data

require '../vendor/autoload.php'; // Include Guzzle HTTP library using Composer

use GuzzleHttp\Client; // Use Guzzle Client for making HTTP requests

$discord_client_id = '1289095716152803359'; // Your Discord application's client ID
$discord_client_secret = 'znAbKPJnh9fZTnBmUk_e2iyztxNT1HtZ'; // Your Discord application's client secret
$redirect_url = 'http://lab-2105cf46-fd70-4e4b-8ece-4494323c5240.australiaeast.cloudapp.azure.com:7037/Assignment/views/DiscordGateway.php'; // URL to redirect after authentication
if (isset($_GET['code'])) { // Check if an authorization code is provided in the URL
    $authorization_code = $_GET['code']; // Retrieve the authorization code

    $http_client = new Client(); // Create a new Guzzle HTTP client
    
    // Request to exchange authorization code for access token
    $token_response = $http_client->request('POST', 'https://discord.com/api/oauth2/token', [
        'form_params' => [ // Parameters to be sent in the POST request
            'client_id' => $discord_client_id, // Discord client ID
            'client_secret' => $discord_client_secret, // Discord client secret
            'grant_type' => 'authorization_code', // Grant type for OAuth2
            'code' => $authorization_code, // The authorization code
            'redirect_uri' => $redirect_url, // The redirect URL
        ],
        'headers' => [ // Set headers for the request
            'Content-Type' => 'application/x-www-form-urlencoded', // Content type of the request
        ],
    ]);
    
    $response_data = json_decode($token_response->getBody(), true); // Decode the JSON response
    $_SESSION['access_token'] = $response_data['access_token']; // Get the access token from response
  
    // Redirect to the user's Discord account page
    header('Location: DiscordLaunch.php'); // Redirect to the account page
    exit; // Stop further script execution
}
