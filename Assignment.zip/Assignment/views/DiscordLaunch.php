<?php
ini_set('display_errors', 1);
session_start();
require '../vendor/autoload.php'; // Guzzle autoload

use GuzzleHttp\Client;


$access_token = $_SESSION['access_token'];
if (!$access_token) {
    echo "No Discord account linked. <a href='discordLinkPage.php'>Link your Discord account</a>";
    exit;
}

$client = new Client();
$headers = [
    'Authorization' => "Bearer $access_token",
];

// Fetch Discord user info
$response = $client->request('GET', 'https://discord.com/api/users/@me', ['headers' => $headers]);
$userInfo = json_decode($response->getBody(), true);

// Fetch Discord guilds (servers)
$response = $client->request('GET', 'https://discord.com/api/users/@me/guilds', ['headers' => $headers]);
$guilds = json_decode($response->getBody(), true);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discord Account</title>
    <style>
        body {
            background-color: #2c2f33; /* Dark background color */
            color: #ffffff; /* White text color */
            font-family: Arial, sans-serif; /* Font style */
            margin: 0; /* Remove default margin */
            padding: 20px; /* Add padding */
        }

        h1, h2 {
            color: #7289da; /* Discord blurple color for headings */
        }

        img {
            border-radius: 50%; /* Make the avatar circular */
            width: 100px; /* Fixed width for avatar */
            height: 100px; /* Fixed height for avatar */
            margin-bottom: 20px; /* Space below the avatar */
        }

        ul {
            list-style-type: none; /* Remove bullet points */
            padding: 0; /* Remove padding */
        }

        li {
            background-color: #42454a; /* Slightly lighter dark for list items */
            margin: 5px 0; /* Margin between list items */
            padding: 10px; /* Padding inside list items */
            border-radius: 5px; /* Rounded corners for list items */
        }
    </style>
</head>
<body>

<h1>Discord Account Details</h1>

<img src="https://cdn.discordapp.com/avatars/<?php echo $userInfo['id']; ?>/<?php echo $userInfo['avatar']; ?>.png" alt="Discord Avatar">
<p>Username: <?php echo htmlspecialchars($userInfo['username']); ?>#<?php echo htmlspecialchars($userInfo['discriminator']); ?></p>

<h2>Servers (Guilds)</h2>
<ul>
    <?php foreach ($guilds as $guild): ?>
        <li><?php echo htmlspecialchars($guild['name']); ?></li>
    <?php endforeach; ?>
</ul>

</body>
</html>
