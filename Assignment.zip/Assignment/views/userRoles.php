<?php 
// Start the session to track user data across pages
session_start(); 

// Enable error reporting for debugging purposes
ini_set('display_errors', 1); 

// Include the database connection file
require_once '../config/connection.php'; 

// Include the UserModel class, which handles user-related database operations
require '../models/authModel.php'; 

// Create a new PDO instance to connect to the database using the credentials defined in dbconn.php
$databaseConnection = new PDO(Source_Name, DataBase_USER, DataBase_PASSWORD);

// Instantiate the UserModel class and pass the database connection to it
$userInstance = new authModel($databaseConnection); 

// Check if the current user is an admin; if not, redirect them to the login page
if ($_SESSION['role'] !== 'admin') { 
    header('Location: loginForm.php'); 
    exit; // Stop further script execution
}

// Retrieve all users from the database using the getAllUsers method in the UserModel class
$allUsers = $userInstance->fetchAllAccounts(); 

// Check if the request method is POST and the form action 'updateRole' has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['updateRole'])) { 
    // Get the user ID and the new role from the form submission
    $selectedUserId = $_POST['user_id']; 
    $updatedRole = $_POST['role']; 

    try {
        // Attempt to update the user's role in the database
        $userInstance->modifyAccountRole($selectedUserId, $updatedRole); 
        echo "<script>alert('User role updated successfully.')</script>"; // Inform the user of success
        header("Refresh:0"); // Refreshes immediately
        exit;
 
    } catch (Exception $exception) {
        // If an error occurs, display an error message
        echo "Error: " . $exception->getMessage(); 
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Permissions Page</title>
    <style>
        body {
            background: #c1bdba; /* Same background as the login page */
            font-family: 'Titillium Web', sans-serif;
            padding: 40px;
            margin: 0;
            background-image: url('https://images.pexels.com/photos/19417092/pexels-photo-19417092/free-photo-of-formula-1-red-bull-rb19-race-car-and-toyota-gr010-hybrid-le-mans-hypercar-in-front-of-the-heydar-aliyev-center-in-baku-azerbaijan.jpeg'); /* Replace with your image URL */
            background-size: cover; 
            background-position: center; 
            background-repeat: no-repeat; 
            background-attachment: fixed;
        }

        h1 {
            text-align: center;
            color: #ffffff;
            font-weight: 300;
            margin: 0 0 40px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 0 auto;
            background: rgba(19, 35, 47, .9); /* Dark table background to match login page form */
            box-shadow: 0 4px 10px 4px rgba(19, 35, 47, .3);
            border-radius: 4px;
            overflow: hidden;
        }

        th, td {
            padding: 15px;
            text-align: left;
            color: #ffffff; /* White text */
        }

        th {
            background-color: #1ab188; /* Green header background */
            text-transform: uppercase;
            font-size: 18px;
        }

        tr:nth-child(even) {
            background: rgba(160, 179, 176, .25); /* Light row color */
        }

        tr:hover {
            background: #178f70; /* Hover effect similar to the login page */
        }

        select {
            padding: 10px;
            font-size: 1em;
            background: rgba(160, 179, 176, .25);
            color: #ffffff;
            border: 1px solid #a0b3b0;
            outline: none;
        }

        .update-role-btn {
            background-color: #1ab188;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            font-size: 1rem;
            text-transform: uppercase;
            transition: background .5s ease;
        }

        .update-role-btn:hover {
            background-color: #178f70;
        }

        form {
            display: flex;
            justify-content: space-between;
        }

        @media (max-width: 768px) {
            table, form {
                display: block;
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="form"> <!-- Container for the table styled similarly to login form -->
        <h1>Permissions Page</h1>
        <table>
            <tr>
                <th>Username</th>
                <th>Role</th>
            </tr>
            <?php foreach ($allUsers as $currentUser): ?> 
                <tr>
                    <td><?php echo htmlspecialchars($currentUser['username']); ?></td>
                    <td>
                        <form method="POST" action="">
                            <input type="hidden" name="user_id" value="<?php echo $currentUser['id']; ?>">
                            <select name="role">
                                <option value="admin" <?php echo ($currentUser['role'] === 'admin') ? 'selected' : ''; ?>>Admin</option>
                                <option value="moderator" <?php echo ($currentUser['role'] === 'moderator') ? 'selected' : ''; ?>>Moderator</option>
                                <option value="basic" <?php echo ($currentUser['role'] === 'basic') ? 'selected' : ''; ?>>Basic</option>
                            </select>
                            <input type="submit" name="updateRole" value="updateRole" class="update-role-btn">
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>
