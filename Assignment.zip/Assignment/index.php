<?php
session_start(); // Start a new session or resume the existing one
ini_set('display_errors', 1); // Enable display of errors
ini_set('display_startup_errors', 1); // Display errors during PHP startup
error_reporting(E_ALL); // Report all PHP errors

require_once 'controllers/authController.php'; // Load the authentication controller
require_once 'models/authModel.php'; // Load the authentication model
require_once 'config/connection.php'; // Include the database connection configuration

// Establish a connection to the database
$databaseConnection = new PDO(Source_Name, DataBase_USER, DataBase_PASSWORD);
$authModel = new authModel($databaseConnection); // Initialize the authentication model
$authController = new authController($authModel); // Initialize the authentication controller

// Retrieve the controller and action from the query string
$operation = $_GET['behavior'] ?? null; // Check if 'operation' exists in the URL

// Handle the user registration process
if ($operation == 'register') {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Collect registration data from the POST request
        $registrationData = [
            'username' => $_POST['username'], // Username from form input
            'password' => $_POST['password'], // Password from form input
            'drivers' => $_POST['drivers'], // Preferences data from form input
            'extra_data' => $_POST['extra_data'] // Extra data from form input
        ];
        $isRegistered = $authController->createAccount($registrationData); // Register user

        // Check if registration was successful
        if ($isRegistered) {
            echo "<script>alert('Registered successfully');</script>";
            include 'views/AuthenticationPage.php'; // Show success page
        } else {
            echo "Registration failed"; // Display error message
        }
    } 
}
// Handle the user login process
elseif ($operation == 'login') {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve username and password from POST request
        $loginName = $_POST['username']; // Username input
        $loginPass = $_POST['password']; // Password input
        
        // Authenticate the user using the provided credentials
        $validatedUser = $authController->verifyLogin($loginName, $loginPass);

        // If the user is authenticated successfully
        if ($validatedUser) {
            // Save user data to the session
            $_SESSION['username'] = $validatedUser['username']; // Store username in session
            $_SESSION['role'] = $validatedUser['role']; // Store user role in session

            // Redirect to a secure page after login
            header("Location: ./views/insightBoard.php");
            exit(); // Stop further script execution
        } else {
            echo "Incorrect username or password."; // Display error for failed login
        }
    } 
}

// Show the landing page if no specific module or operation is provided
else {
    include 'views/AuthenticationPage.php'; // Display the default landing page
}
?>
