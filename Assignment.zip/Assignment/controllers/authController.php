<?php
require_once 'models/authModel.php'; // Load the authentication model

class AuthController {
    private $authModel; // Store the model for database operations

    // Constructor to initialize the authentication model
    public function __construct($authModel) {
        $this->authModel = $authModel;
    }

    // Function to register a new user
    public function createAccount($registrationData) {

        // Encrypt sensitive preferences (e.g., drivers)
        $secureKey = 'abcdef'; // Encryption key (insecure example, use a strong key)
        $encryptionIv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc')); // Generate Initialization Vector
        $encryptedPreferences = openssl_encrypt($registrationData['drivers'], 'aes-256-cbc', $secureKey, 0, $encryptionIv); // Encrypt user preferences
        $encodedIv = base64_encode($encryptionIv); // Encode IV for storage

        // Hash the password using SHA-256 with the salt
        $securePasswordHash = hash('sha256', $registrationData['password'] . $encodedIv); // Combine password with salt and hash it

        $defaultRole = 'member'; // Default user role
        // Save the user information into the database using the model
        return $this->authModel->storeUser(
            $registrationData['username'], // Store the username
            $securePasswordHash, // Store the hashed password
            $encodedIv, // Store the encoded IV (salt)
            $encryptedPreferences, // Store encrypted preferences
            $registrationData['extra_data'], // Store additional data
            $defaultRole // Assign default role
        );
    }
    
    // Function to log in an existing user
    public function verifyLogin($loginHandle, $loginPass) {
        // Retrieve the user's stored password hash and salt by username
        $existingUser = $this->authModel->getAccountByAlias($loginHandle);
    
        if ($existingUser) {
            // Extract stored password and salt
            $savedPasswordHash = $existingUser['password']; // Stored hashed password
            $savedSalt = $existingUser['salt']; // Stored salt (encoded)
            
            // Rehash the input password with the stored salt
            $rehashPassword = hash('sha256', $loginPass . $savedSalt); // Combine input password with saved salt and hash it
            
            // Compare the stored hashed password with the rehashed password
            if ($rehashPassword === $savedPasswordHash) {
                return $existingUser; // Return user details if passwords match
            } else {
                return false; // Return false if passwords do not match
            }
        } else {
            return false; // Return false if the user is not found
        }
    }
}
?>
