<?php
class authModel {
    private $dbConnection; // Holds the database connection

    public function __construct($dbConnection) {
        $this->dbConnection = $dbConnection; // Store the database connection object
    }

    // Add a new account to the database
    public function storeUser($userAlias, $securePassword, $randomSalt, $encryptedVehicleInfo, $encryptedExtraInfo) {
        $queryStatement = $this->dbConnection->prepare("INSERT INTO users (username, password, salt, drivers, extra_data, role) VALUES (?, ?, ?, ?, ?, ?)");
        $role = 'basic';
        return $queryStatement->execute([$userAlias, $securePassword, $randomSalt, $encryptedVehicleInfo, $encryptedExtraInfo, $role]); // Insert the account data
    }

    // Retrieve account details based on alias
    public function getAccountByAlias($userAlias) {
        $queryStatement = $this->dbConnection->prepare('SELECT * FROM users WHERE username = :username');
        $queryStatement->execute(['username' => $userAlias]); // Fetch the account with the provided alias
        return $queryStatement->fetch(PDO::FETCH_ASSOC); // Return the result as an associative array
    }

    // Retrieve a list of all accounts
    public function fetchAllAccounts() {
        $queryStatement = $this->dbConnection->prepare("SELECT * FROM users");
        $queryStatement->execute(); // Execute the query to get all account details
        return $queryStatement->fetchAll(PDO::FETCH_ASSOC); // Return the fetched data as an array
    }

    // Update the role of a specific account
    public function modifyAccountRole($accountId, $updatedRole) {
        $permittedRoles = ['admin', 'moderator', 'basic']; // Define the valid roles
        if (!in_array($updatedRole, $permittedRoles)) {
            throw new Exception('Invalid role assignment.'); // Check if the role is allowed
        }

        // Prepare the query for role update
        $queryStatement = $this->dbConnection->prepare("UPDATE users SET role = :role WHERE id = :id");
        $queryStatement->bindParam(':role', $updatedRole); // Bind the updated role to the query
        $queryStatement->bindParam(':id', $accountId); // Bind the account ID to the query

        // Execute the query to update the role
        if ($queryStatement->execute()) {
            return true; // Return true if the update is successful
        } else {
            return false; // Return false if the update fails
        }
    }
}
?>
