<?php
define('Source_Name', 'mysql:host=localhost;dbname=514');
define('DataBase_USER', 'root');
define('DataBase_PASSWORD', 'Dhara@528');
?>