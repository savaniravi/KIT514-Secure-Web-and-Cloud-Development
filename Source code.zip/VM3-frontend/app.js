// app.js
const express = require('express');
const path = require('path');
const dotenv = require('dotenv');
const bodyParser = require('body-parser');
const driverRoutes = require('./routes/drivers');
const carRoutes = require('./routes/cars');
const trackRoutes = require('./routes/tracks');
const raceRoutes = require('./routes/races');

dotenv.config();

const app = express();
const PORT = 3389;

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.use('/drivers', driverRoutes);
app.use('/cars', carRoutes);
app.use('/tracks', trackRoutes);
app.use('/races', raceRoutes);

// Home route
app.get('/', (req, res) => {
  res.render('index');
});

// Start server
app.listen(PORT, () => {
  console.log(`Frontend server is running on port ${PORT}`);
});
