// controllers/driverController.js
const axios = require('axios');
const teamApiBaseUrl = "http://lab-2105cf46-fd70-4e4b-8ece-4494323c5240.australiaeast.cloudapp.azure.com:7037";

// List all drivers
exports.listDrivers = async (req, res) => {
  try {
    const response = await axios.get(`${teamApiBaseUrl}/driver`);
    res.render('drivers/list', { drivers: response.data.result, error: null });
  } catch (error) {
    res.render('drivers/list', { drivers: [], error: 'Failed to fetch drivers.' + error });
  }
};

// Show the create driver form
exports.showCreateForm = (req, res) => {
  res.render('drivers/create', { error: null });
};

// Create a new driver
exports.createDriver = async (req, res) => {
  const { number, shortName, name, skillRace, skillStreet } = req.body;

  try {
    await axios.post(`${teamApiBaseUrl}/driver`, {
      shortName,
      name,
      skill: {
        race: parseInt(skillRace, 10),
        street: parseInt(skillStreet, 10),
      },
    });
    res.redirect('/drivers');
  } catch (error) {
    res.render('drivers/create', { error: 'Failed to create driver.' });
  }
};

// Show driver details
exports.driverDetails = async (req, res) => {
  const driverId = req.params.id;

  try {
    const response = await axios.get(`${teamApiBaseUrl}/driver/${driverId}`);
    res.render('drivers/details', { driver: response.data.result, error: null });
  } catch (error) {
    res.render('drivers/details', { error: 'Failed to fetch driver details.' });
  }
};

// Delete a driver
exports.deleteDriver = async (req, res) => {
  const driverId = req.params.id;

  try {
    await axios.delete(`${teamApiBaseUrl}/driver/${driverId}`);
    res.redirect('/drivers');
  } catch (error) {
    res.redirect('/drivers');
  }
};
