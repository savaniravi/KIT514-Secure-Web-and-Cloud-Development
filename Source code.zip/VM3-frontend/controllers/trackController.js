// controllers/trackController.js
const axios = require('axios');
const raceApiBaseUrl = 'http://lab-95a11ac6-8103-422e-af7e-4a8532f40144.australiaeast.cloudapp.azure.com:7057';

// List all tracks
exports.listTracks = async (req, res) => {
  try {
    const response = await axios.get(`${raceApiBaseUrl}/track`);
    const tracks = response.data.result;

    // Fetch number of races for each track
    const tracksWithRaceCounts = await Promise.all(
      tracks.map(async (track) => {
        const racesResponse = await axios.get(`${raceApiBaseUrl}/track/${track.id}/races`);
        track.raceCount = racesResponse.data.result.length;
        return track;
      })
    );

    res.render('tracks/list', { tracks: tracksWithRaceCounts, error: null });
  } catch (error) {
    res.render('tracks/list', { tracks: [], error: 'Failed to fetch tracks.' });
  }
};

// Show the create track form
exports.showCreateForm = (req, res) => {
  res.render('tracks/create', {error: null});
};

// Create a new track
exports.createTrack = async (req, res) => {
  const { name, laps, baseLapTime, type } = req.body;

  try {
    await axios.post(`${raceApiBaseUrl}/track`, {
      name,
      laps: parseInt(laps, 10),
      baseLapTime: parseFloat(baseLapTime).toFixed(2),
      type,
    });
    res.redirect('/tracks');
  } catch (error) {
    res.render('tracks/create', { error: 'Failed to create track.' });
  }
};

// Scrape tracks and display them on a new page
exports.scrapeTracks = async (req, res) => {
  try {
    const response = await axios.get(`${raceApiBaseUrl}/track/scrape`);
    const scrapedTracks = response.data.result;
    res.render('tracks/scraped_tracks', { scrapedTracks, error: null });
  } catch (error) {
    res.render('tracks/scraped_tracks', { scrapedTracks: [], error: 'Failed to scrape tracks.' });
  }
};

// Add a scraped track to the database
exports.addScrapedTrack = async (req, res) => {
  const { name, laps, baseLapTime, type } = req.body;

  try {
    await axios.post(`${raceApiBaseUrl}/track`, {
      name,
      laps: parseInt(laps, 10),
      baseLapTime: parseFloat(baseLapTime).toFixed(2),
      type,
    });
    res.redirect('/tracks');
  } catch (error) {
    res.redirect('/tracks/scrape', { error: 'Failed to add track from scraped data.' });
  }
};

// Delete a track
exports.deleteTrack = async (req, res) => {
  const trackId = req.params.id;

  try {
    await axios.delete(`${raceApiBaseUrl}/track/${trackId}`);
    res.redirect('/tracks');
  } catch (error) {
    res.redirect('/tracks', { error: 'Failed to delete track.' });
  }
};

// Start a race for a specific track
exports.startRace = async (req, res) => {
    const trackId = req.params.id;
  
    try {
      // Send a POST request to create a new race for the specified track
      await axios.post(`${raceApiBaseUrl}/track/${trackId}/races`);
      res.redirect('/races');
    } catch (error) {
      console.error('Failed to start race:', error);
      res.redirect('/tracks', { error: 'Failed to start race.' });
    }
  };
