// controllers/raceController.js
const axios = require('axios');
const timingApiBaseUrl = 'http://lab-95a11ac6-8103-422e-af7e-4a8532f40144.australiaeast.cloudapp.azure.com:7057';
const teamsApiUrl = 'http://lab-2105cf46-fd70-4e4b-8ece-4494323c5240.australiaeast.cloudapp.azure.com:7037';

// List all races
exports.listRaces = async (req, res) => {
  try {
    const response = await axios.get(`${timingApiBaseUrl}/race`);
    const races = response.data.result;

    const racesWithDetails = await Promise.all(
      races.map(async (race) => {
        const entrantsCount = race.entrants.length;
        const lapsDone = race.laps.length;
        return { ...race, entrantsCount, lapsDone };
      })
    );

    res.render('races/list', { races: racesWithDetails, error: null });
  } catch (error) {
    res.render('races/list', { races: [], error: 'Failed to fetch races.' });
  }
};


// Show race details
exports.raceDetails = async (req, res) => {
  const raceId = req.params.id;

  try {
    const raceResponse = await axios.get(`${timingApiBaseUrl}/race/${raceId}`);
    const race = raceResponse.data.result;

    let leaderboard = null;
    let error = null;

    // Check if starting positions are set
    const startingPositionsAssigned = race.startingPositions && race.startingPositions.length > 0;

    if (startingPositionsAssigned) {
      try {
        const leaderboardResponse = await axios.get(`${timingApiBaseUrl}/race/${raceId}/leaderboard`);
        leaderboard = leaderboardResponse.data.result;
        //console.log(leaderboard)
      } catch (leaderboardError) {
        if (leaderboardError.response && leaderboardError.response.status === 404) {
          error = leaderboardError.response.data.message;
        } else {
          error = 'Failed to retrieve leaderboard.';
        }
      }
    } else {
      error = 'Starting positions have not been assigned. Leaderboard and lap registration are disabled.';
    }

    res.render('races/details', { race, leaderboard, error, startingPositionsAssigned });
  } catch (error) {
    console.error('Failed to fetch race details:', error);
    res.render('races/details', {
      race: null,
      leaderboard: null,
      error: 'Failed to fetch race details.',
      startingPositionsAssigned: false,  // Ensure startingPositionsAssigned is set to false on error
    });
  }
};


// Render Assign Entrant page
exports.showAssignEntrantPage = async (req, res) => {
    const { id } = req.params;
  
    try {
      // Fetch race details from the Race API server
      const raceResponse = await axios.get(`${timingApiBaseUrl}/race/${id}`);
      const race = raceResponse.data.result;
  
      if (!race) {
        return res.status(404).json({ code: 404, message: 'Race not found' });
      }
  
      // Fetch all available cars from the Teams API
      const carResponse = await axios.get(`${teamsApiUrl}/car`);
      const cars = carResponse.data.result;
  
      res.render('races/assign_entrant', { raceId: id, cars, error: null });
    } catch (error) {
      // console.error('Failed to load assign entrant page:', error);
      res.render('races/assign_entrant', { raceId: id, cars, error: error });
    }
  };
  
  // Assign the selected car as an entrant to the race
  exports.assignEntrant = async (req, res) => {
    const { id } = req.params;
    const { carId } = req.body;

    try {
      // Send request to add the car as an entrant
      await axios.post(`${timingApiBaseUrl}/race/${id}/entrant`, { carUri: `${teamsApiUrl}/car/${carId}` });
      res.redirect(`/races/${id}`);
    } catch (error) {
      console.error('Failed to assign entrant:', error.response ? error.response.data : error.message);

      // Fetch available cars again to display on the page
      try {
        const carResponse = await axios.get(`${teamsApiUrl}/car`);
        const cars = carResponse.data.result;
        
        // Render the page with the error message
        const errorMessage = error.response && error.response.data && error.response.data.message 
          ? error.response.data.message 
          : 'Failed to assign entrant. Please try again.';
          
        res.render('races/assign_entrant', { raceId: id, cars, error: errorMessage });
      } catch (fetchError) {
        console.error('Failed to reload cars for assign entrant page:', fetchError);
        res.render('races/assign_entrant', { raceId: id, cars: [], error: 'Failed to assign entrant and load available cars. Please try again later.' });
      }
    }
};


// Set starting positions for a race
exports.qualifyEntrants = async (req, res) => {
  const raceId = req.params.id;

  try {
    await axios.post(`${timingApiBaseUrl}/race/${raceId}/qualify`);
    res.redirect('/races');
  } catch (error) {
    const errorMessage = error.response && error.response.data && error.response.data.message
      ? error.response.data.message
      : 'Failed to set starting positions.';

    // Fetch all races again to show the list with the error message
    try {
      const response = await axios.get(`${timingApiBaseUrl}/race`);
      const races = response.data.result;

      const racesWithDetails = await Promise.all(
        races.map(async (race) => {
          const entrantsCount = race.entrants.length;
          const lapsDone = race.laps.length;
          return { ...race, entrantsCount, lapsDone };
        })
      );

      res.render('races/list', { races: racesWithDetails, error: errorMessage });
    } catch (fetchError) {
      res.render('races/list', { races: [], error: 'Failed to fetch races after setting starting positions.' });
    }
  }
};


// Register a new lap for the race
exports.addLapToRace = async (req, res) => {
  const raceId = req.params.id;

  try {
    await axios.post(`${timingApiBaseUrl}/race/${raceId}/lap`);
    res.redirect(`/races/${raceId}`);
  } catch (error) {
    res.redirect(`/races/${raceId}`);
  }
};

