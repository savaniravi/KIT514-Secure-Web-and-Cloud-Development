// controllers/carController.js
const axios = require('axios');
const teamApiBaseUrl = 'http://lab-2105cf46-fd70-4e4b-8ece-4494323c5240.australiaeast.cloudapp.azure.com:7037';

// List all cars
exports.listCars = async (req, res) => {
  try {
    const response = await axios.get(`${teamApiBaseUrl}/car`);
    res.render('cars/list', { cars: response.data.result, error: null  });
  } catch (error) {
    res.render('cars/list', { cars: [], error: 'Failed to fetch cars.' });
  }
};

// Show the create car form
exports.showCreateForm = (req, res) => {
  res.render('cars/create', { error: null });
};

// Create a new car
exports.createCar = async (req, res) => {
  const { raceSuitability, streetSuitability, reliability } = req.body;

  try {
    await axios.post(`${teamApiBaseUrl}/car`, {
      suitability: {
        race: parseInt(raceSuitability),
        street: parseInt(streetSuitability),
      },
      reliability: parseInt(reliability, 10),
    });
    res.redirect('/cars');
  } catch (error) {
    res.render('cars/create', { error: 'Failed to create car. ' + error });
  }
};

// Show car details
exports.carDetails = async (req, res) => {
  const carId = req.params.id;

  try {
    const carResponse = await axios.get(`${teamApiBaseUrl}/car/${carId}`);
    const driverResponse = await axios.get(`${teamApiBaseUrl}/car/${carId}/driver`);
    const car = carResponse.data.result;
    const driver = driverResponse.data.result;

    res.render('cars/details', { car, driver, error: null });
  } catch (error) {
    res.render('cars/details', { error: 'Failed to fetch car details.' });
  }
};

// Assign a driver to a car
exports.assignDriver = async (req, res) => {
  const carId = req.params.id;
  const { driverNumber } = req.body;

  try {
    await axios.put(`${teamApiBaseUrl}/car/${carId}/driver`, { driverNumber });
    res.redirect(`/cars/${carId}`);
  } catch (error) {
    res.redirect(`/cars/${carId}`);
  }
};

// Remove the driver from a car
exports.removeDriver = async (req, res) => {
  const carId = req.params.id;

  try {
    await axios.delete(`${teamApiBaseUrl}/car/${carId}/driver`);
    res.redirect(`/cars/${carId}`);
  } catch (error) {
    res.redirect(`/cars/${carId}`);
  }
};

// Delete a car
exports.deleteCar = async (req, res) => {
    const carId = req.params.id;
  
    try {
      await axios.delete(`${teamApiBaseUrl}/car/${carId}`);
      res.redirect('/cars');
    } catch (error) {
      res.redirect('/cars');
    }
  };
