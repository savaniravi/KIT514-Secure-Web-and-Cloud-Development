// routes/cars.js
const express = require('express');
const router = express.Router();
const carController = require('../controllers/carController');

// List all cars
router.get('/', carController.listCars);

// Show create car form
router.get('/create', carController.showCreateForm);

// Handle car creation
router.post('/create', carController.createCar);

// Show car details
router.get('/:id', carController.carDetails);

// Assign a driver to a car
router.post('/:id/assign-driver', carController.assignDriver);

// Remove the driver from a car
router.post('/:id/remove-driver', carController.removeDriver);

// Delete a car
router.post('/:id/delete', carController.deleteCar);


module.exports = router;
