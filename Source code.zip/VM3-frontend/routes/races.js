// routes/races.js
const express = require('express');
const router = express.Router();
const raceController = require('../controllers/raceController');

// List all races
router.get('/', raceController.listRaces);

// Show race details (leaderboard, lap times)
router.get('/:id', raceController.raceDetails);

// Render Assign Entrant page
router.get('/:id/assign-entrant', raceController.showAssignEntrantPage);

// Handle Assign Entrant submission
router.post('/:id/assign-entrant', raceController.assignEntrant);

// Set starting positions for a race
router.post('/:id/qualify', raceController.qualifyEntrants);

// Register a new lap for the race
router.post('/:id/lap', raceController.addLapToRace);

module.exports = router;
