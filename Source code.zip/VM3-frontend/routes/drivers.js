// routes/drivers.js
const express = require('express');
const router = express.Router();
const driverController = require('../controllers/driverController');

// List all drivers
router.get('/', driverController.listDrivers);

// Show create driver form
router.get('/create', driverController.showCreateForm);

// Handle driver creation
router.post('/create', driverController.createDriver);

// Show driver details
router.get('/:id', driverController.driverDetails);

// Delete a driver
router.post('/:id/delete', driverController.deleteDriver);

module.exports = router;
