// routes/tracks.js
const express = require('express');
const router = express.Router();
const trackController = require('../controllers/trackController');

// List all tracks
router.get('/', trackController.listTracks);

// Show create track form
router.get('/create', trackController.showCreateForm);

// Handle track creation
router.post('/create', trackController.createTrack);

// Scrape tracks from external source
router.get('/scrape', trackController.scrapeTracks);

// Show scraped tracks and allow adding them
router.post('/add-scraped-track', trackController.addScrapedTrack);

// Delete a track
router.post('/:id/delete', trackController.deleteTrack);

// Start a race for a specific track
router.post('/:id/start-race', trackController.startRace);

module.exports = router;
