// controllers/raceController.js
const { Race, Track } = require('../models');
const teamsApiUrl = 'http://localhost:4444';
const axios = require('axios');

// Get all races
const getAllRaces = async (req, res) => {
  try {
    let races = await Race.findAll();

    // Convert stringified JSON fields to proper JSON objects
    races = races.map(race => ({
      ...race.toJSON(),
      entrants: typeof race.entrants === 'string' ? JSON.parse(race.entrants || '[]') : race.entrants,
      startingPositions: typeof race.startingPositions === 'string' ? JSON.parse(race.startingPositions || '[]') : race.startingPositions,
      laps: typeof race.laps === 'string' ? JSON.parse(race.laps || '[]') : race.laps
    }));

    res.status(200).json({ code: 200, result: races });
  } catch (error) {
    res.status(500).json({ code: 500, message: 'Failed to retrieve races', error });
  }
};

// Get a specific race by ID
const getRaceById = async (req, res) => {
  const { id } = req.params;
  try {
    const race = await Race.findByPk(id);

    if (race) {
      // Convert stringified JSON fields to proper JSON objects
      const raceData = {
        ...race.toJSON(),
        entrants: typeof race.entrants === 'string' ? JSON.parse(race.entrants || '[]') : race.entrants,
        startingPositions: typeof race.startingPositions === 'string' ? JSON.parse(race.startingPositions || '[]') : race.startingPositions,
        laps: typeof race.laps === 'string' ? JSON.parse(race.laps || '[]') : race.laps
      };

      res.status(200).json({ code: 200, result: raceData });
    } else {
      res.status(404).json({ code: 404, message: 'Race not found' });
    }
  } catch (error) {
    res.status(500).json({ code: 500, message: 'Failed to retrieve race', error });
  }
};

// Get all entrants with details for a specific race
const getEntrantsByRaceId = async (req, res) => {
  const { id } = req.params;

  try {
    const race = await Race.findByPk(id);
    if (!race) {
      return res.status(404).json({ code: 404, message: 'Race not found' });
    }

    // Parse entrants from the race
    const entrants = JSON.parse(race.entrants || '[]');

    // Fetch detailed info for each entrant from the Teams API
    const detailedEntrants = await Promise.all(
      entrants.map(async (carId) => {
        try {
          const carResponse = await axios.get(`${teamsApiUrl}/car/${carId}`);
          const car = carResponse.data.result;

          // Fetch driver details if a driver is associated with the car
          let driver = null;
          if (car.driver) {
            const driverResponse = await axios.get(`${teamsApiUrl}/driver/${car.driver.number}`);
            driver = driverResponse.data.result;
          }

          return {
            car,
            driver,
          };
        } catch (error) {
          console.error(`Failed to fetch details for car ${carId}:`, error);
          return { car: null, driver: null };
        }
      })
    );

    res.status(200).json({ code: 200, result: detailedEntrants });
  } catch (error) {
    res.status(500).json({ code: 500, message: 'Failed to retrieve entrants', error });
  }
};

const addEntrantToRace = async (req, res) => {
  const { id } = req.params;
  const { carUri } = req.body;

  try {
    const race = await Race.findByPk(id);
    if (!race) {
      return res.status(404).json({ code: 404, message: 'Race not found' });
    }

    // Parse entrants only if it's a string
    let entrants = typeof race.entrants === 'string' ? JSON.parse(race.entrants) : race.entrants;
    if (!Array.isArray(entrants)) {
      entrants = [];
    }

    // Ensure the car is not already an entrant
    if (entrants.includes(carUri)) {
      return res.status(400).json({ code: 400, message: 'Car is already an entrant in this race' });
    }

    // Fetch car details from the Teams API
    const carResponse = await axios.get(carUri);
    const car = carResponse.data.result;

    // Check if the car has a driver assigned
    if (!car.driver) {
      return res.status(400).json({ code: 400, message: 'Car cannot be added as an entrant because it has no driver' });
    }

    // Add car to entrants array
    entrants.push(carUri);

    // Update entrants field with the modified array
    race.entrants = JSON.stringify(entrants); // Store as a JSON string if needed by the database
    await race.save();

    res.status(201).json({ code: 201, message: 'Car added to race entrants', result: race });
  } catch (error) {
    console.error(error);
    res.status(500).json({ code: 500, message: 'Failed to add entrant to race', error: error.message });
  }
};


// Remove a car from a race's entrants
const removeEntrantFromRace = async (req, res) => {
  const { id } = req.params;
  const { carUri } = req.body;
  try {
    const race = await Race.findByPk(id);
    if (!race) {
      return res.status(404).json({ code: 404, message: 'Race not found' });
    }

    // Ensure the car is an entrant
    if (!race.entrants.includes(carUri)) {
      return res.status(400).json({ code: 400, message: 'Car is not an entrant in this race' });
    }

    // Remove car from entrants
    race.entrants = race.entrants.filter(uri => uri !== carUri);
    await race.save();

    res.status(200).json({ code: 200, message: 'Car removed from race entrants', result: race });
  } catch (error) {
    res.status(500).json({ code: 500, message: 'Failed to remove entrant from race', error });
  }
};

// Set starting positions for a race
const qualifyEntrants = async (req, res) => {
  const { id } = req.params;

  try {
    const race = await Race.findByPk(id);
    if (!race) {
      return res.status(404).json({ code: 404, message: 'Race not found' });
    }

    // Parse entrants if they are stored as a string
    const entrants = typeof race.entrants === 'string' ? JSON.parse(race.entrants) : race.entrants;
    if (!entrants || entrants.length === 0) {
      return res.status(400).json({ code: 400, message: 'No entrants found in this race' });
    }

    // Check if starting positions are already set
    const startingPositions = typeof race.startingPositions === 'string' ? JSON.parse(race.startingPositions) : race.startingPositions;
    if (startingPositions && startingPositions.length > 0) {
      return res.status(400).json({ code: 400, message: 'Starting positions have already been set' });
    }

    // Retrieve track type directly from the Track model
    const track = await Track.findByPk(race.trackId);
    if (!track) {
      return res.status(404).json({ code: 404, message: 'Track not found for this race' });
    }
    const trackType = track.type; // "race" or "street"

    // Fetch driver skill data for each entrant and prepare them for sorting
    const entrantsWithSkills = await Promise.all(
      entrants.map(async (carUri) => {
        try {
          // Fetch car details
          const carResponse = await axios.get(carUri);
          const car = carResponse.data.result;

          // Fetch driver details if assigned
          if (car.driver) {
            const driverResponse = await axios.get(car.driver.uri);
            const driver = driverResponse.data.result;
            const skill = driver.skill[trackType]; // skill for the track type

            return {
              carUri,
              skill,
            };
          } else {
            // Skip cars with no driver assigned
            return null;
          }
        } catch (error) {
          console.error(`Failed to fetch details for entrant ${carUri}:`, error);
          return null;
        }
      })
    );

    // Filter out any null entrants (those without drivers) and sort by descending skill
    const sortedEntrants = entrantsWithSkills
      .filter((entrant) => entrant !== null)
      .sort((a, b) => b.skill - a.skill)
      .map((entrant) => entrant.carUri); // Only keep carUri for starting positions

    // Update the race with the new starting positions
    race.startingPositions = sortedEntrants; // Store as JSON string if needed by database
    await race.save();

    res.status(200).json({ code: 200, message: 'Starting positions set', result: sortedEntrants });
  } catch (error) {
    console.error('Failed to set starting positions:', error);
    res.status(500).json({ code: 500, message: 'Failed to set starting positions', error });
  }
};

// Get laps for a specific race
const getLapsByRaceId = async (req, res) => {
  const { id } = req.params;
  try {
    const race = await Race.findByPk(id);
    if (!race) {
      return res.status(404).json({ code: 404, message: 'Race not found' });
    }
    res.status(200).json({ code: 200, result: race.laps });
  } catch (error) {
    res.status(500).json({ code: 500, message: 'Failed to retrieve laps for the race', error });
  }
};


// Add a lap to a race
const addLapToRace = async (req, res) => {
  const { id } = req.params;

  try {
    const race = await Race.findByPk(id);
    if (!race) {
      return res.status(404).json({ code: 404, message: 'Race not found' });
    }

    // Fetch track details directly from the database
    const track = await Track.findByPk(race.trackId);
    if (!track) {
      return res.status(404).json({ code: 404, message: 'Track not found for this race' });
    }

    const { type: trackType, baseLapTime } = track;

    // Parse entrants as JSON if it's a string
    const entrants = typeof race.entrants === 'string' ? JSON.parse(race.entrants) : race.entrants;
    if (!Array.isArray(entrants) || entrants.length === 0) {
      return res.status(400).json({ code: 400, message: 'No entrants found for this race' });
    }

    // Prepare lap data for each entrant by fetching lap times from the Teams API
    const lapTimes = await Promise.all(
      entrants.map(async (carUri, index) => {
        try {
          // Request lap time from the Teams API for each car
          const lapResponse = await axios.get(`${carUri}/lap`, {
            data: { trackType, baseLapTime }
          });
          const { time, randomness, crashed } = lapResponse.data;
          return {
            entrant: index,
            time: parseFloat(time),
            randomness: parseFloat(randomness),
            crashed,
          };
        } catch (error) {
          console.error(`Failed to fetch lap time for ${carUri}:`, error);
          return {
            entrant: index,
            time: 0,
            randomness: 0,
            crashed: true,
          };
        }
      })
    );

    // Add the new lap to the race
    const lap = {
      number: race.laps.length,
      lapTimes,
    };

    // Ensure race.laps is properly parsed as JSON if needed
    const laps = typeof race.laps === 'string' ? JSON.parse(race.laps) : race.laps;
    laps.push(lap);

    // Update race with the new lap and save it
    race.laps = JSON.stringify(laps);
    await race.save();

    res.status(201).json({ code: 201, message: 'Lap added', result: lap });
  } catch (error) {
    console.error('Failed to add lap:', error);
    res.status(500).json({ code: 500, message: 'Failed to add lap', error });
  }
};

// Get leaderboard for a specific lap in a race
const getLeaderboardByLapNumber = async (req, res) => {
  const { id, number } = req.params;
  try {
    const race = await Race.findByPk(id);
    if (!race || !race.laps[number]) {
      return res.status(404).json({ code: 404, message: 'Lap not found' });
    }

    // Calculate leaderboard for the specific lap (simplified for now)
    const leaderboard = race.laps[number].lapTimes
      .filter(entry => !entry.crashed)
      .sort((a, b) => a.time - b.time);

    res.status(200).json({ code: 200, result: leaderboard });
  } catch (error) {
    res.status(500).json({ code: 500, message: 'Failed to retrieve leaderboard', error });
  }
};

// Get the latest leaderboard for a race
const getLatestLeaderboard = async (req, res) => {
  const { id } = req.params;
  try {
    const race = await Race.findByPk(id);

    // Check if the race exists and parse laps as JSON if necessary
    if (!race) {
      return res.status(404).json({ code: 404, message: 'Race not found' });
    }

    // Parse laps if stored as a string
    const laps = typeof race.laps === 'string' ? JSON.parse(race.laps) : race.laps;

    // Check if there are any laps recorded
    if (!Array.isArray(laps) || laps.length === 0) {
      return res.status(404).json({ code: 404, message: 'No laps found for this race' });
    }

    // Calculate total time and laps completed for each entrant
    const leaderboard = {};

    laps.forEach((lap) => {
      lap.lapTimes.forEach((entry) => {
        const { entrant, time, crashed } = entry;

        // Skip crashed entrants
        if (crashed) return;

        // Initialize the leaderboard entry if it doesn't exist
        if (!leaderboard[entrant]) {
          leaderboard[entrant] = {
            entrant,
            totalTime: 0,
            lapsCompleted: 0,
          };
        }

        // Add the lap time and increment the lap count
        leaderboard[entrant].totalTime += time;
        leaderboard[entrant].lapsCompleted += 1;
      });
    });

    // Convert leaderboard object to an array and sort by laps completed, then by total time
    const sortedLeaderboard = Object.values(leaderboard)
      .sort((a, b) => {
        if (b.lapsCompleted !== a.lapsCompleted) {
          return b.lapsCompleted - a.lapsCompleted; // Sort by laps completed first
        }
        return a.totalTime - b.totalTime; // If laps are equal, sort by total time
      });

    res.status(200).json({ code: 200, result: sortedLeaderboard });
  } catch (error) {
    console.error('Failed to retrieve latest leaderboard:', error);
    res.status(500).json({ code: 500, message: 'Failed to retrieve latest leaderboard', error });
  }
};

module.exports = {
  getAllRaces,
  getRaceById,
  getEntrantsByRaceId,
  addEntrantToRace,
  removeEntrantFromRace,
  qualifyEntrants,
  getLapsByRaceId,
  addLapToRace,
  getLeaderboardByLapNumber,
  getLatestLeaderboard,
};
