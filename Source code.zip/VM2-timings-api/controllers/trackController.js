// controllers/trackController.js
const { Track, Race } = require('../models');
const teamsApi = require('../utils/teamsApi');
const { scrapeTracks } = require('../utils/scraper');

// Get all tracks
const getAllTracks = async (req, res) => {
  try {
    const tracks = await Track.findAll();
    res.status(200).json({ code: 200, result: tracks });
  } catch (error) {
    res.status(500).json({ code: 500, message: 'Failed to retrieve tracks', error });
  }
};

// Add a new track
const addTrack = async (req, res) => {
  const { name, type, laps, baseLapTime } = req.body;
  try {
    const track = await Track.create({ name, type, laps, baseLapTime });
    res.status(201).json({ code: 201, result: track });
  } catch (error) {
    res.status(500).json({ code: 500, message: 'Failed to add track', error });
  }
};

// Get a specific track by ID
const getTrackById = async (req, res) => {
  const { id } = req.params;
  try {
    const track = await Track.findByPk(id);
    if (track) {
      res.status(200).json({ code: 200, result: track });
    } else {
      res.status(404).json({ code: 404, message: 'Track not found' });
    }
  } catch (error) {
    res.status(500).json({ code: 500, message: 'Failed to retrieve track', error });
  }
};

// Delete a track by ID
const deleteTrack = async (req, res) => {
  const { id } = req.params;
  try {
    const track = await Track.findByPk(id);
    if (!track) {
      return res.status(404).json({ code: 404, message: 'Track not found' });
    }

    // Check if any races are associated with the track
    const races = await Race.findAll({ where: { trackId: id } });
    if (races.length > 0) {
      return res.status(400).json({ code: 400, message: 'Cannot delete track with existing races' });
    }

    await track.destroy();
    res.status(200).json({ code: 200, message: 'Track deleted successfully' });
  } catch (error) {
    res.status(500).json({ code: 500, message: 'Failed to delete track', error });
  }
};

// Get all races for a specific track
const getRacesByTrackId = async (req, res) => {
  const { id } = req.params;
  try {
    const races = await Race.findAll({ where: { trackId: id } });
    res.status(200).json({ code: 200, result: races });
  } catch (error) {
    res.status(500).json({ code: 500, message: 'Failed to retrieve races for the track', error });
  }
};

// Create a new race for a specific track
const createRaceForTrack = async (req, res) => {
  const { id } = req.params;
  try {
    const track = await Track.findByPk(id);
    if (!track) {
      return res.status(404).json({ code: 404, message: 'Track not found' });
    }

    const race = await Race.create({ trackId: id });
    res.status(201).json({ code: 201, result: race });
  } catch (error) {
    res.status(500).json({ code: 500, message: 'Failed to create race for track', error });
  }
};

// Scrape track data
const scrapeTrackData = async (req, res) => {
    try {
      const tracks = await scrapeTracks();
      res.status(200).json({ code: 200, result: tracks });
    } catch (error) {
      res.status(500).json({ code: 500, message: 'Failed to scrape track data', error });
    }
  };

module.exports = {
  getAllTracks,
  addTrack,
  getTrackById,
  deleteTrack,
  getRacesByTrackId,
  createRaceForTrack,
  scrapeTrackData,
};
