// routes/raceRoutes.js
const express = require('express');
const raceController = require('../controllers/raceController');
const router = express.Router();

// Get all races
router.get('/', raceController.getAllRaces);

// Get a specific race by ID
router.get('/:id', raceController.getRaceById);

// Get all entrants for a specific race
router.get('/:id/entrant', raceController.getEntrantsByRaceId);

// Add a car to a race's entrants
router.post('/:id/entrant', raceController.addEntrantToRace);

// Remove a car from a race's entrants
router.delete('/:id/entrant', raceController.removeEntrantFromRace);

// Set starting positions for a race
router.post('/:id/qualify', raceController.qualifyEntrants);

// Get laps for a specific race
router.get('/:id/lap', raceController.getLapsByRaceId);

// Add a lap to a race
router.post('/:id/lap', raceController.addLapToRace);

// Get leaderboard for a specific lap in a race
router.get('/:id/lap/:number', raceController.getLeaderboardByLapNumber);

// Get the latest leaderboard for a race
router.get('/:id/leaderboard', raceController.getLatestLeaderboard);

module.exports = router;
