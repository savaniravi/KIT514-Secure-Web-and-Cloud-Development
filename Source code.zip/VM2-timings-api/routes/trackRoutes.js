// routes/trackRoutes.js
const express = require('express');
const trackController = require('../controllers/trackController');
const router = express.Router();

// Get all tracks
router.get('/', trackController.getAllTracks);

// Add a new track
router.post('/', trackController.addTrack);

// Scrape Formula 1 website for track data
router.get('/scrape', trackController.scrapeTrackData);

// Get a specific track by ID
router.get('/:id', trackController.getTrackById);

// Delete a track by ID
router.delete('/:id', trackController.deleteTrack);

// Get all races for a specific track
router.get('/:id/races', trackController.getRacesByTrackId);

// Create a new race for a specific track
router.post('/:id/races', trackController.createRaceForTrack);



module.exports = router;
