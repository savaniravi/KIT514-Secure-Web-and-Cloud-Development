// utils/scraper.js
const axios = require('axios');
const cheerio = require('cheerio');

const BASE_URL = 'https://www.formula1.com';
const TRACK_LINK_SELECTOR = 'a[href^="/en/racing/2024/"]';

async function scrapeTracks() {
    try {
      const response = await axios.get(`${BASE_URL}/en/racing/2024`);
      const $ = cheerio.load(response.data);
      const trackPromises = [];
  
      $(TRACK_LINK_SELECTOR).each((index, element) => {
        const relativeLink = $(element).attr('href');
        if (relativeLink) {
          const trackDetailsLink = `${BASE_URL}${relativeLink}/circuit`;
          // Store each promise for track details
          trackPromises.push(getTrackDetails(trackDetailsLink));
        }
      });
  
      const tracks = await Promise.all(trackPromises); // Wait for all promises to resolve
      const validTracks = tracks.filter(track => track && track.name); // Filter out any null or undefined tracks
  
      // console.log(validTracks.length); // Check the number of valid tracks for logging purpose
  
      return validTracks;
    } catch (error) {
      console.error('Failed to scrape track data:', error);
      throw error;
    }
  }
  

async function getTrackDetails(url) {
    try {
      const response = await axios.get(url);
      const $ = cheerio.load(response.data);
      const trackDetails = {};
  
      // Extract track name
      trackDetails.name = $('h2').first().text().trim();
  
      // Targeting the specific divs based on the observed structure
        $('div.border-r-double.border-b-double').each((index, element) => {
            const statLabel = $(element).find('span').text().trim();
            let statValue = $(element).find('h2').text().trim();
        
            // console.log(`Label: "${statLabel}"`); // Log each label to verify its content
        
            if (statLabel.toLowerCase() === 'number of laps') {
            trackDetails.laps = parseInt(statValue, 10) || 50; // Default to 50 if missing
            }
        
            if (statLabel.toLowerCase().includes('lap record')) { // Check if label contains "Lap Record"
            // console.log(`Lap Record Found: "${statValue}"`); // Log the Lap Record value
            statValue = statValue.split(' ')[0]; // Extract only the time part (e.g., "1:11.097")
            const timeParts = statValue.split(':');
            if (timeParts.length === 2) {
                const minutes = parseInt(timeParts[0], 10);
                const seconds = parseFloat(timeParts[1]);
                trackDetails.baseLapTime = minutes * 60 + seconds;
            }
            } else if (statLabel.toLowerCase() === 'circuit length') {
            trackDetails.length = parseFloat(statValue.split(' ')[0]);
            } else if (statLabel.toLowerCase() === 'race distance') {
            trackDetails.raceDistance = parseFloat(statValue.split(' ')[0]);
            }
        });
  
  
      // Determine track type by checking the presence of "street" keywords in circuit info
      const circuitInfoText = $('#maincontent > div').text().toLowerCase();
      if (circuitInfoText.includes('street')) {
        trackDetails.type = 'street';
      } else {
        trackDetails.type = 'race';
      }
  
      // console.log(trackDetails);
      return trackDetails;
    } catch (error) {
      console.error(`Failed to scrape details for ${url}:`, error);
      return null;
    }
  }
  
module.exports = { scrapeTracks };
