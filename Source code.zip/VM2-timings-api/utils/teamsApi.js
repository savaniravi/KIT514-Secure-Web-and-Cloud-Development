// utils/teamsApi.js
const axios = require('axios');
require('dotenv').config();

const teamsApiUrl = process.env.TEAMS_API_URL;

// Get lap time for a specific car based on the track data
const getCarLapTime = async (carId, trackData) => {
  try {
    const response = await axios.get(`${teamsApiUrl}/car/${carId}/lap`, {
      params: trackData,
    });
    return response.data;
  } catch (error) {
    console.error('Failed to fetch car lap time:', error);
    throw error;
  }
};

module.exports = {
  getCarLapTime,
};
