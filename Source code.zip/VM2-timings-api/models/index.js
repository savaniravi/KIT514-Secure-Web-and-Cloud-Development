// models/index.js
const sequelize = require('../db');
const Track = require('./Track');
const Race = require('./Race');

// Associations
Race.belongsTo(Track, { foreignKey: 'trackId', as: 'track' });
Track.hasMany(Race, { foreignKey: 'trackId', as: 'races' });

const models = { Track, Race };

const initializeModels = async () => {
  try {
    await sequelize.authenticate();
    console.log('Database connected successfully.');
    await sequelize.sync({ alter: true }); // Use { force: true } to recreate tables
  } catch (error) {
    console.error('Unable to connect to the database:', error);
  }
};

module.exports = { ...models, sequelize, initializeModels };
