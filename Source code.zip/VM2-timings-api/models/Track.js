// models/Track.js
const { DataTypes } = require('sequelize');
const sequelize = require('../db');

const Track = sequelize.define('Track', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  type: {
    type: DataTypes.ENUM('race', 'street'),
    allowNull: false,
  },
  laps: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 1,
    },
  },
  baseLapTime: {
    type: DataTypes.FLOAT,
    allowNull: false,
  },
});

module.exports = Track;
