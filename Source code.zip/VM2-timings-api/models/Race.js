// models/Race.js
const { DataTypes } = require('sequelize');
const sequelize = require('../db');

const Race = sequelize.define('Race', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  trackId: {
    type: DataTypes.INTEGER,
    references: {
      model: 'Tracks',
      key: 'id',
    },
    allowNull: false,
  },
  entrants: {
    type: DataTypes.JSON,
    allowNull: true,
    defaultValue: [],
  },
  startingPositions: {
    type: DataTypes.JSON,
    allowNull: true,
    defaultValue: [],
  },
  laps: {
    type: DataTypes.JSON,
    allowNull: true,
    defaultValue: [],
  },
});

module.exports = Race;
