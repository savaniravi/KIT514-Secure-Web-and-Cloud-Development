// app.js
const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const trackRoutes = require('./routes/trackRoutes');
const raceRoutes = require('./routes/raceRoutes');
const { initializeModels } = require('./models');

dotenv.config();

const app = express();
const PORT = 3389;

// Middleware
app.use(cors()); // Enable CORS
app.use(express.json()); // Parse JSON request bodies

// Routes
app.use('/track', trackRoutes);
app.use('/race', raceRoutes);

// Initialize models and start server
initializeModels().then(() => {
  app.listen(PORT, () => {
    console.log(`Timing Service API is running on port ${PORT}`);
  });
}).catch((error) => {
  console.error('Failed to initialize models:', error);
});
