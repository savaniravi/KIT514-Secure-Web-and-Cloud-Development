// app.js
const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const carRoutes = require('./routes/carRoutes');
const driverRoutes = require('./routes/driverRoutes');
const { initializeModels } = require('./models');

dotenv.config();

const app = express();
const PORT = 3389;

// Middle ware for CORS
app.use(cors());

// Middleware for parsing JSON
app.use(express.json());

// Routes
app.use('/car', carRoutes);
app.use('/driver', driverRoutes);

// Start the server and initialize models
initializeModels().then(() => {
  app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });
}).catch((error) => {
  console.error('Failed to initialize models:', error);
});
