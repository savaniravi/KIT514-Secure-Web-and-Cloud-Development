// models/Driver.js
const { DataTypes } = require('sequelize');
const sequelize = require('../db');

const Driver = sequelize.define('Driver', {
  number: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  shortName: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  skill: {
    type: DataTypes.JSON,
    allowNull: false,
    validate: {
      checkSkill(value) {
        const { race, street } = value;
        if (race + street !== 100) {
          throw new Error('Skill ratings for race and street tracks must sum to 100.');
        }
      },
    },
  },
});

module.exports = Driver;
