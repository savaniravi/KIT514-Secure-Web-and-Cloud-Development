// models/index.js
const sequelize = require('../db');
const Car = require('./Car');
const Driver = require('./Driver');

// Associations
Car.belongsTo(Driver, { foreignKey: 'driverId', as: 'driver' });
Driver.hasMany(Car, { foreignKey: 'driverId', as: 'cars' });

const models = { Car, Driver };

const initializeModels = async () => {
  try {
    await sequelize.authenticate();
    console.log('Database connected successfully.');
    await sequelize.sync({ alter: true }); // Use { force: true } to drop tables and recreate them
  } catch (error) {
    console.error('Unable to connect to the database:', error);
  }
};

module.exports = { ...models, sequelize, initializeModels };
