// models/Car.js
const { DataTypes } = require('sequelize');
const sequelize = require('../db');

const Car = sequelize.define('Car', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  suitability: {
    type: DataTypes.JSON,
    allowNull: false,
    validate: {
      checkSuitability(value) {
        const { race, street } = value;
        if (race + street !== 100) {
          throw new Error('Suitability ratings for race and street tracks must sum to 100.');
        }
      },
    },
  },
  reliability: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 0,
      max: 100,
    },
  },
});

module.exports = Car;
