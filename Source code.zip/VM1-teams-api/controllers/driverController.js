// controllers/driverController.js
const { Driver } = require('../models');

// Get all drivers
exports.getAllDrivers = async (req, res) => {
  try {
    const drivers = await Driver.findAll();
    const result = drivers.map(driver => ({
      number: driver.number,
      shortName: driver.shortName,
      name: driver.name,
      skill: driver.skill, 
    }));
    
    res.status(200).json({ code: 200, result });
  } catch (error) {
    console.log(error)
    res.status(500).json({ error: 'Failed to fetch drivers' });
  }
};

// Add a new driver
exports.addDriver = async (req, res) => {
  try {
    const { shortName, name, skill } = req.body;

    // Ensure skill ratings sum to 100
    if (skill.race + skill.street !== 100) {
      return res.status(400).json({ error: 'Skill ratings for race and street tracks must sum to 100.' });
    }

    const newDriver = await Driver.create({ shortName, name, skill });
    res.status(201).json({ message: 'Driver added successfully', driver: newDriver });
  } catch (error) {
    res.status(500).json({ error: 'Failed to add driver' });
  }
};

// Get a specific driver by number
exports.getDriverByNumber = async (req, res) => {
  try {
    const driver = await Driver.findOne({ where: { number: req.params.number } });
    if (!driver) {
      return res.status(404).json({ error: 'Driver not found' });
    }

    const result = {
      number: driver.number,
      shortName: driver.shortName,
      name: driver.name,
      skill: driver.skill, 
    };

    res.status(200).json({ code: 200, result });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch driver' });
  }
};

// Update a driver by number
exports.updateDriver = async (req, res) => {
  try {
    const driver = await Driver.findOne({ where: { number: req.params.number } });
    if (!driver) {
      return res.status(404).json({ error: 'Driver not found' });
    }

    const { shortName, name, skill } = req.body;

    if (skill && skill.race + skill.street !== 100) {
      return res.status(400).json({ error: 'Skill ratings for race and street tracks must sum to 100.' });
    }

    await driver.update({ shortName, name, skill });
    res.status(200).json({ message: 'Driver updated successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update driver' });
  }
};

// Delete a driver by number
exports.deleteDriver = async (req, res) => {
  try {
    const driver = await Driver.findOne({ where: { number: req.params.number } });
    if (!driver) {
      return res.status(404).json({ error: 'Driver not found' });
    }

    await driver.destroy();
    res.status(200).json({ message: 'Driver deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete driver' });
  }
};
