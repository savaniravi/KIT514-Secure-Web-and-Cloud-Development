// controllers/carController.js
const { Car, Driver } = require('../models');

// Get all cars
exports.getAllCars = async (req, res) => {
  try {
    const cars = await Car.findAll({
      include: [
        {
          model: Driver,
          as: 'driver',
          attributes: ['name', 'number'],
        },
      ],
    });

    const result = cars.map(car => ({
      id: car.id,
      driver: car.driver
        ? { name: car.driver.name, uri: `${req.protocol}://${req.get('host')}/driver/${car.driver.number}` }
        : null,
      suitability: car.suitability,
      reliability: car.reliability,
    }));

    res.status(200).json({ code: 200, result });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch cars' });
  }
};

// Add a new car
exports.addCar = async (req, res) => {
  try {
    const { suitability, reliability } = req.body;
    const newCar = await Car.create({ suitability: suitability, reliability });
    res.status(201).json({ message: 'Car added successfully', car: newCar });
  } catch (error) {
    console.log(error)
    res.status(500).json({ error: 'Failed to add car' });
  }
};

// Get a specific car by ID
exports.getCarById = async (req, res) => {
  try {
    const car = await Car.findByPk(req.params.id, {
      include: [
        {
          model: Driver,
          as: 'driver',
          attributes: ['name', 'number'],
        },
      ],
    });

    if (!car) {
      return res.status(404).json({ error: 'Car not found' });
    }

    const result = {
      id: car.id,
      driver: car.driver
        ? { name: car.driver.name, uri: `${req.protocol}://${req.get('host')}/driver/${car.driver.number}` }
        : null,
      suitability: car.suitability,
      reliability: car.reliability,
    };

    res.status(200).json({ code: 200, result });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch car' });
  }
};

// Update a car by ID
exports.updateCar = async (req, res) => {
  try {
    const car = await Car.findByPk(req.params.id);
    if (!car) {
      return res.status(404).json({ error: 'Car not found' });
    }
    await car.update(req.body);
    res.status(200).json({ message: 'Car updated successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update car' });
  }
};

// Delete a car by ID
exports.deleteCar = async (req, res) => {
  try {
    const car = await Car.findByPk(req.params.id);
    if (!car) {
      return res.status(404).json({ error: 'Car not found' });
    }
    await car.destroy();
    res.status(200).json({ message: 'Car deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete car' });
  }
};

// Get the driver of a specific car
exports.getCarDriver = async (req, res) => {
  try {
    const car = await Car.findByPk(req.params.id, {
      include: [{ model: Driver, as: 'driver', attributes: ['shortName', 'number'] }],
    });
    if (!car) {
      return res.status(404).json({ error: 'Car not found' });
    }
    res.status(200).json({ driver: car.driver || null });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch car driver' });
  }
};

// Assign a driver to a car
exports.assignDriverToCar = async (req, res) => {
  try {
    const car = await Car.findByPk(req.params.id);
    if (!car) return res.status(404).json({ error: 'Car not found' });

    const driver = await Driver.findOne({ where: { number: req.body.driverNumber } });
    if (!driver) return res.status(404).json({ error: 'Driver not found' });

    const existingCar = await Car.findOne({ where: { driverId: driver.number } });
    if (existingCar) return res.status(400).json({ error: 'Driver is already assigned to another car' });

    await car.update({ driverId: driver.number });
    res.status(200).json({ message: 'Driver assigned to car successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to assign driver to car' });
  }
};

// Remove the driver from a car
exports.removeDriverFromCar = async (req, res) => {
  try {
    const car = await Car.findByPk(req.params.id);
    if (!car) return res.status(404).json({ error: 'Car not found' });

    await car.update({ driverId: null });
    res.status(200).json({ message: 'Driver removed from car successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to remove driver from car' });
  }
};

// Get lap time for a car
exports.getCarLapTime = async (req, res) => {
  try {
    const { trackType, baseLapTime } = req.body;
    const car = await Car.findByPk(req.params.id, { include: { model: Driver, as: 'driver' } });

    if (!car) return res.status(404).json({ error: 'Car not found' });
    if (!car.driver) return res.status(418).json({ error: 'Car has no driver assigned' });

    // Ensure baseLapTime is a valid number
    if (isNaN(baseLapTime)) {
      return res.status(400).json({ error: 'Invalid baseLapTime provided' });
    }

    // Parse and validate car suitability and driver skill
    const suitability = car.suitability;
    const driverSkill = car.driver.skill[trackType];
    const trackSuitability = suitability[trackType];

    if (typeof trackSuitability === 'undefined' || typeof driverSkill === 'undefined') {
      return res.status(400).json({ error: 'Missing suitability or driver skill for specified track type' });
    }

    // Calculate crash chance based on reliability
    const reliabilityFactor = trackType === 'street' ? car.reliability + 10 : car.reliability + 5;
    const randomFactor = Math.random() * 5;
    const crashCheck = Math.random() * 100;

    // Determine if the car crashes
    const crashed = crashCheck > car.reliability;

    if (crashed) {
      return res.json({ time: 0, randomness: randomFactor.toFixed(3), crashed: true });
    }

    // Calculate lap time based on suitability, driver skill, and reliability
    const speedFactor = (trackSuitability + driverSkill + (100 - car.reliability)) / 3;
    const lapTime = baseLapTime + (10 * (speedFactor / 100)) + randomFactor;

    res.json({ time: lapTime.toFixed(2), randomness: randomFactor.toFixed(3), crashed: false });
  } catch (error) {
    console.error('Failed to calculate lap time:', error);
    res.status(500).json({ error: 'Failed to calculate lap time' });
  }
};
