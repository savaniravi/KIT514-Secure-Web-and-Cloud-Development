// routes/driverRoutes.js
const express = require('express');
const driverController = require('../controllers/driverController');
const router = express.Router();

// Get all drivers
router.get('/', driverController.getAllDrivers);

// Add a new driver
router.post('/', driverController.addDriver);

// Get a specific driver by number
router.get('/:number', driverController.getDriverByNumber);

// Update a driver by number
router.put('/:number', driverController.updateDriver);

// Delete a driver by number
router.delete('/:number', driverController.deleteDriver);

module.exports = router;
