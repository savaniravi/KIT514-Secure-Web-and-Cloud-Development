// routes/carRoutes.js
const express = require('express');
const carController = require('../controllers/carController');
const router = express.Router();

// Get all cars
router.get('/', carController.getAllCars);

// Add a new car
router.post('/', carController.addCar);

// Get a specific car by ID
router.get('/:id', carController.getCarById);

// Update a car by ID
router.put('/:id', carController.updateCar);

// Delete a car by ID
router.delete('/:id', carController.deleteCar);

// Get the driver of a specific car
router.get('/:id/driver', carController.getCarDriver);

// Assign a driver to a car
router.put('/:id/driver', carController.assignDriverToCar);

// Remove the driver from a car
router.delete('/:id/driver', carController.removeDriverFromCar);

// Get lap time for a car (requires track data)
router.get('/:id/lap', carController.getCarLapTime);

module.exports = router;
